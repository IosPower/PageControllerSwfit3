//
//  ViewController.swift
//  PageControll_SeparateStoryBoard_Swift
//

import UIKit

class ViewController: UIViewController,UIPageViewControllerDataSource,UIPageViewControllerDelegate {

    @IBOutlet weak var viewForPage: UIView!
    
    @IBOutlet weak var pagecontrollNew: UIPageControl!
    
    var pageControl: UIPageControl!
    var indicatorindex: Int!
    
    var firstVC: FirstViewController?
    var secondVC: SecondViewController?
    var thirdVC: ThirdViewController?
    var fourthVC: FourthViewController?
    
    internal var pageController: UIPageViewController = UIPageViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        PageviewcontrollerSetup() // PageViewController Setup Function
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func PageviewcontrollerSetup()  {
        indicatorindex=0;
        self.pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        self.pageController.dataSource = self
        self.pageController.delegate = self
        self.pageController.view!.frame = CGRect(x: 0, y: 0, width: self.viewForPage.frame.size.width, height: self.viewForPage.frame.size.height)

        firstVC = self.storyboard?.instantiateViewController(withIdentifier: "FirstViewController") as? FirstViewController
        
        secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController
        
        thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as? ThirdViewController
        
        fourthVC = self.storyboard?.instantiateViewController(withIdentifier: "FourthViewController") as? FourthViewController
    
//        // Default pagecontrol from pageviewcontroller
//        pageControl = UIPageControl.appearance()
//        pageControl.tintColor = UIColor.blackColor()
//        pageControl.pageIndicatorTintColor = UIColor.grayColor()
//        pageControl.currentPageIndicatorTintColor = UIColor.redColor()
//        pageControl.layer.borderColor = UIColor.redColor().CGColor
//        pageControl.layer.borderWidth = 0.5
//        pageControl.layer.masksToBounds = true
//        pageControl.backgroundColor = UIColor.clearColor()
//        pageControl.hidden = true

        let viewControllers: NSArray  = [firstVC!]
        self.pageController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: true, completion: { _ in })
        self.addChildViewController(self.pageController)
        self.viewForPage!.addSubview(self.pageController.view!)
        self.pageController.didMove(toParentViewController: self)
        self.pagecontrollNew.currentPage = 0;
        self.view.bringSubview(toFront: self.pagecontrollNew)
        
        print("\(self.pageController.view.frame.size.height)")
        
//        for view1 in self.pageController.view.subviews{
//            
//            if view1 is UIScrollView {
//                let scrollview: UIScrollView = view1 as! UIScrollView
//                scrollview.isScrollEnabled = false
//            }
//        }
    }
    
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
    
        if (self.pageController.viewControllers![0] == fourthVC) {
            
            self.pagecontrollNew.currentPage = 3;
            indicatorindex=3;
            return thirdVC;
        }
        else if (self.pageController.viewControllers![0] == thirdVC) {
            self.pagecontrollNew.currentPage = 2;
            indicatorindex=2;
            return secondVC;
        }
        else if (self.pageController.viewControllers![0] == secondVC) {
            self.pagecontrollNew.currentPage = 1;
            indicatorindex=1;
            return firstVC;
        }
        else if (self.pageController.viewControllers![0] == firstVC){
            self.pagecontrollNew.currentPage = 0;
            indicatorindex=0;
            return nil;
        }
        return nil;
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        if (self.pageController.viewControllers![0] == firstVC){
            self.pagecontrollNew.currentPage = 0;
            indicatorindex=0;
            return secondVC;
        }
        else if (self.pageController.viewControllers![0] == secondVC){
            self.pagecontrollNew.currentPage = 1;
            indicatorindex=1;
            return thirdVC;
        }
        else if (self.pageController.viewControllers![0] == thirdVC){
            self.pagecontrollNew.currentPage = 2;
            indicatorindex=2;
            return fourthVC;
        }
        else if (self.pageController.viewControllers![0] == fourthVC){
            self.pagecontrollNew.currentPage = 3;
            indicatorindex=3;
            return nil;
        }
        return nil
    }
    
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int{
        return 4
    }
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return indicatorindex!
    }
    
    // MARK: - PageViewController Delegate Method
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool){
        guard completed else { return }
        
        print(indicatorindex)
        
        print(pageViewController.viewControllers?.first?.view)
        self.pagecontrollNew.currentPage = pageViewController.viewControllers!.first!.view.tag
        
      //  indicatorindex = pageViewController.viewControllers!.first!.view.tag
        print("didFinishAnimating index = \(indicatorindex)")
    }

}

