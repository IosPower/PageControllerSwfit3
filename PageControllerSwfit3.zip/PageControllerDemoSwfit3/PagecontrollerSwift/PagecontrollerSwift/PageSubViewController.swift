//
//  PageSubViewController.swift
//  PagecontrollerSwift
//


import UIKit

class PageSubViewController: UIViewController {

    // MARK: - outlets
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgview: UIImageView!
    
     // MARK: - Variable Declare here
    var index: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
       // print(index)
        
        lblTitle.text = "Screen\(index)"
        var imgarray = ["24.png","25.png","28.png","30.png","31.png"]
        imgview.image = UIImage(named: imgarray[index])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
