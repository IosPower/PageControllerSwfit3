//
//  ViewController.swift
//  PagecontrollerSwift
//

import UIKit

class ViewController: UIViewController, UIPageViewControllerDataSource,UIPageViewControllerDelegate,UIScrollViewDelegate{
    
     // MARK: - outlets
    
    @IBOutlet weak var viewForpage: UIView!
    
     // MARK: - Variable Declare here
    var pageControl: UIPageControl!
    var indicatorindex: Int!
    
    internal var pageController: UIPageViewController = UIPageViewController()
    
     // MARK: - viewDidLoad  And start from here
    
    override func viewDidLoad() {
        super.viewDidLoad()
        PageviewcontrollerSetup() // PageViewController Setup Function
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - PageviewcontrollerSetup  Function
    
    func PageviewcontrollerSetup()
    {
        indicatorindex=0;
        self.pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        self.pageController.dataSource = self
        self.pageController.delegate = self
        self.pageController.view!.frame = CGRect(x: 0, y: 0, width: self.viewForpage.frame.size.width, height: self.viewForpage.frame.size.height)
        
       // Default pagecontrol from pageviewcontroller
        pageControl = UIPageControl.appearance()
        pageControl.tintColor = UIColor.black
        pageControl.pageIndicatorTintColor = UIColor.gray
        pageControl.currentPageIndicatorTintColor = UIColor.red
        pageControl.layer.borderColor = UIColor.red.cgColor
        pageControl.layer.borderWidth = 0.5
        pageControl.layer.masksToBounds = true
        pageControl.backgroundColor = UIColor.clear
        pageControl.isHidden = false
        
        let initialViewController: PageSubViewController =  self.viewControllerAtIndex(0)
        let viewControllers = [initialViewController]
        self.pageController.setViewControllers(viewControllers, direction: .forward, animated: true, completion: { _ in })
        self.addChildViewController(self.pageController)
        
        self.viewForpage!.addSubview(self.pageController.view!)
        self.pageController.didMove(toParentViewController: self)
        NSLog("%f", self.pageController.view.frame.size.height)
        
        // subViews From Pageviewcontroller
        var subviews: [AnyObject] = self.pageController.view.subviews
        for i in 0 ..< subviews.count {
            if (subviews[i] is UIPageControl) {
                pageControl = (subviews[i] as! UIPageControl)
            }
            else {
                let scroll: UIScrollView = subviews[i] as! UIScrollView
                scroll.delegate = self
                scroll.bounces = true
            }
        }
        
        //        pageControl.hidden = true
        //        pageControl.removeFromSuperview()
        
    }
    
    // MARK: - PageViewController dataSource Method
    
    func viewControllerAtIndex(_ index: Int) -> PageSubViewController {
        let childViewController: PageSubViewController = self.storyboard?.instantiateViewController(withIdentifier: "PageSubViewController") as! PageSubViewController
        childViewController.index = index
        childViewController.view.tag = index
        return childViewController
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        var index: Int = (viewController as! PageSubViewController).index
        if index == 0 {
          return nil
        }
        // Decrease the index by 1 to return
        index -= 1
        return self.viewControllerAtIndex(index)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        var index: Int = (viewController as! PageSubViewController).index
        index += 1
        if index == 5 {
            return nil
        }else{
            return self.viewControllerAtIndex(index)
        }
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int{
        return 5
    }
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return indicatorindex!
    }
    
     // MARK: - PageViewController Delegate Method
    
     func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool){
        guard completed else { return }
        self.pageControl.currentPage = pageViewController.viewControllers!.first!.view.tag
        indicatorindex = pageViewController.viewControllers!.first!.view.tag
        print("didFinishAnimating index = \(indicatorindex)")
     }
    
     // MARK: - ScrollView  Method
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        print("scrollViewDidEndDecelerating = \(indicatorindex)")
        if indicatorindex == 0 || indicatorindex == 4{
            // scrollView.bounces = false
        }
        else{
            //  scrollView.bounces = true
        }
    }
}

